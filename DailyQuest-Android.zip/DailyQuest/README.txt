1. Install Android Studio, then File > Open > this DailyQuest folder (let it sync).
2. Connect your phone (USB debugging on) and press Run, or Build > Build APK(s).
3. First launch: allow "Display over other apps" for Daily Quest.
4. Settings > Apps > Daily Quest > Battery > Unrestricted (on Xiaomi/Oppo/Vivo also allow "pop-up while in background" and autostart).
